plot.ttest <-
function(x,...) {
    
}
